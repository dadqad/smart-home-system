#include "tim2.h"
#include "delay.h"
#include "stm32f10x.h"

/************************************************/
void PWM_Init(u16 arr,u16 psc)
{		 		
	GPIO_InitTypeDef 		 	 GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef		 TIM_TimeBaseStructure;		
	TIM_OCInitTypeDef  	 		 TIM_OCInitStructure;			  

	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);	
 	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE); 


	/*			IO�ڹܽ�����		*/
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;	  
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;  				  				
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	
	/*			��ʱ��3����			*/
	
	TIM_TimeBaseStructure.TIM_Period            = arr;       
	TIM_TimeBaseStructure.TIM_Prescaler         = psc; 		           
	TIM_TimeBaseStructure.TIM_ClockDivision     = 0; 	 
	TIM_TimeBaseStructure.TIM_CounterMode       = TIM_CounterMode_Up; 
	TIM_TimeBaseStructure.TIM_RepetitionCounter = 0; 
	TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);                
	
	/*		PWMͨ������		*/
	TIM_OCInitStructure.TIM_OCMode       = TIM_OCMode_PWM1;   //����pwm�����ģʽ    	 
 	TIM_OCInitStructure.TIM_OutputState  = TIM_OutputState_Enable; 
	TIM_OCInitStructure.TIM_Pulse        = arr * 0.2;	//����ռ�ձ�      	 	 
	TIM_OCInitStructure.TIM_OCPolarity   = TIM_OCPolarity_Low; //����pwm���������Ϊ��	
	
  TIM_OC2Init(TIM2, &TIM_OCInitStructure);  //��ʼ��     											

	TIM_OC2PreloadConfig(TIM2, TIM_OCPreload_Enable);  ///ʹ��Ԥװ�ؼĴ���   	 
	
	TIM_Cmd(TIM2, ENABLE);
	TIM2->CR1|=0x01;   //ʹ�ܶ�ʱ��3 

}

