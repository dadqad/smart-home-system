#ifndef __LED_H
#define __LED_H	 
#include "stm32f10x.h"


void Motor_Init(void);


#define MOTOR1DIR PBout(3)
#define MOTOR1En PBout(5)
#define MOTOR2DIR PBout(2)
#define MOTOR2En PBout(6)

#endif
